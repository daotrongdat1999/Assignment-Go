package main

import (
	"fmt"
	"sync"
	"time"
)

//khai báo biến để sử dụng synchronize
var wg sync.WaitGroup
//var mu sync.Mutex
//struct student
type Student struct{
	name string
	course string
}

//chia việc cho worker
func StAndCourse(student []Student){
	//gán cờ done
	defer wg.Done()

	//tạo 2 channel để chia việc cho worker
	jobs := make(chan Student, len(student))
	result := make(chan Student, len(student))
	
	//chia việc cho 3 worker
	for i := 0; i < 3; i++ {
		go worker(jobs, result)
	}
	
	//gán student vào cho các job
	for i := 0; i < len(student); i++ {
		jobs <- student[i]
	}
	close(jobs)
	
	go PrintCourses(result)
	time.Sleep(time.Second)
}

//hàm tạo worker pool
func worker(jobs <-chan Student, result chan<- Student){
	defer wg.Done()
	for n := range jobs{
		result <- n
	}
}

//hàm receiver in student với tên và course đã đăng ký
func PrintCourses(SChan <-chan  Student){
	//in giá trị trong channel
	for i := 0; i < cap(SChan); i++ {
		fmt.Println(<-SChan)
	}
}

func main(){
	//khai báo mảng sinh viên gán giá trị
	var student = [8]Student{}
	student[0] = Student{"Dat", "Go"}
	student[1] = Student{"Dat2", "Go2"}
	student[2] = Student{"Dat3", "Go3"}
	student[3] = Student{"Dat4", "Go4"}
	student[4] = Student{"Dat5", "Go5"}
	student[5] = Student{"Dat6", "Go6"}
	student[6] = Student{"Dat7", "Go7"}
	student[7] = Student{"Dat8", "Go8"}
	wg.Add(1)
	//value cho sender in ra
	go StAndCourse(student[:])	
	wg.Wait()
}
