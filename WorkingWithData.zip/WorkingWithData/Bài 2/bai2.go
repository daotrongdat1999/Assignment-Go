package main

import (
	"fmt"
	"io/ioutil"
	"sync"
	"time"
)

//read file
// func JobShare(filename []string){
// 	//tạo 2 kênh để chia việc cho worker
// 	jobs := make(chan string, len(filename))
// 	result := make(chan string, len(filename))

// 	//chia việc cho worker
// 	for i := 0; i < 3; i++ {
// 		go worker(jobs, result)
// 	}
// 	//gán file name vào job
// 	for i := 0; i < len(filename); i++ {
// 		jobs <-filename[i]
// 	}
// 	close(jobs)

// 	readWrite(result)

// 	time.Sleep(time.Second)

// }

//worker
// func worker(jobs <-chan string, result chan<- string){
// 	for n := range jobs{
// 		result <- n
// 	}
// }

//read write
func readWrite(fileName string){
	defer w.Done()
	contents,_ := ioutil.ReadFile(fileName)
	tmpName := "output/" + fileName
	ioutil.WriteFile(tmpName, contents, 0644)
}
var w sync.WaitGroup
func main(){

	fileName := []string{"file1.doc", "file2.txt", "file3.docx", "file4.txt", "file5.docx", "file6.xlsx", "file7.txt"}

	//
	start1 := time.Now()
	w.Add(7)
	for i := 0; i < len(fileName); i++ {
		go readWrite(fileName[i])
	}
	w.Wait()
	//JobShare(fileName[:])
	end1 := time.Since(start1)

	fmt.Printf("Took: %s", end1)
}