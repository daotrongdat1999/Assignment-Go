package main

import (
	"fmt"
	"strings"
	"sync"
	"time"
)
var w sync.WaitGroup
type Tweet struct{
	userName string
	tweet string
}

func Sequen(tweet []Tweet){
	for i := 0; i < len(tweet); i++ {
		if strings.Contains(tweet[i].tweet, "golang"){
			fmt.Printf("%0.15s %s %s", tweet[i].userName, "tweet about Golang", "\n")
		} else{
			fmt.Printf("%0.15s %s %s", tweet[i].userName, "does not tweet about Golang", "\n")
		}
	}
}

func Concurent(tweet []Tweet){
	defer w.Done()

	for i := 0; i < len(tweet); i++ {
		if strings.Contains(tweet[i].tweet, "golang"){
			fmt.Printf("%0.15s %s %s", tweet[i].userName, "tweet about Golang", "\n")
		} else{
			fmt.Printf("%0.15s %s %s", tweet[i].userName, "does not tweet about Golang", "\n")
		}
	}
}

func main(){
	var mockdata = []Tweet{
    {
        "anhlv16",
        "#golang top tip: if your unit tests import any other package you wrote, including themselves, they're not unit tests.",
    }, {
        "beertocode",
        "Backend developer, doing frontend featuring the eternal struggle of centering something. #coding",
    }, {
        "zz00zz",
        "Re: Popularity of Golang in China: My thinking nowadays is that it had a lot to do with this book and author https://github.com/astaxie/build-web-application-with-golang",
    }, {
        "Lmao",
        "Looking forward to the #gopher meetup in Hsinchu tonight with @ironzeb!",
    }, {
        "vampirewalk666",
        "I just wrote a golang slack bot! It reports the state of github repository. #Slack #golang",
    }, {
        "tuandoan2604",
        "I just wrote a golang slack bot! It reports the state of github repository. #Slack #golang",
    }, {
        "aloalo1234",
        "I just wrote a java slack bot! It reports the state of github repository. #Slack",
    }, {
        "toilatoi1234",
        "golang!!!",
    },
}

start1 := time.Now()
Sequen(mockdata)
end1 := time.Since(start1)
fmt.Printf("Sequent took: %s %s", end1, "\n")
fmt.Println("________________________________________________")
start2 := time.Now()

w.Add(1)
go Concurent(mockdata)
w.Wait()
end2 := time.Since(start2)
fmt.Printf("Concurent took: %s", end2)
}