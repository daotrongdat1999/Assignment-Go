package main

import (
	"errors"
	"fmt"
	"os"
	"strconv"
	"time"
)

var (
	ErrLogin  error = errors.New("login error, your Email or Password is invalid") //lỗi đăng nhập
	ErrChosen error = errors.New("invalid chosen")                                 //lỗi lựa chọn
)

type Bank interface {
	//đăng ký
	Register()
	//đăng nhập
	Login()
	//rút tiền
	Withdraw()
	//gửi tiền
	Deposit()
}

//kiểu thông tin ngày sinh
type Birthday struct {
	Day   int
	Month int
	Year  int
}

//kiểu thông tin xác thực
type Authen struct {
	Email    string
	Phone    string
	Password string
	ID       string
}

//kiểu thông tin tài khoản
type Account struct {
	Name string
	Birthday
	Authen
	Money   float64
	History string
}

// hàm đăng ký
func (ac *Account) Register(Account Account) Account {
	//nhập vào thông tin của Account, số dư tài khoản mặc định là 0
	fmt.Println("Nhập vào thông tin tài khoản theo thứ tự Tên, Ngày sinh, Tháng sinh, Năm sinh, Email, Số điện thoại, Mật khẩu, ID. Mỗi thông tin cách nhau bởi khoảng trắng:")
	fmt.Scan(&Account.Name, &Account.Day, &Account.Month, &Account.Year, &Account.Email, &Account.Phone, &Account.Password, &Account.ID)
	fmt.Println("Đăng ký thành công")
	return Account
}

//hàm kiểm tra đăng nhập, trả về ID của user đăng nhập thành công
func Login(Authen Authen, Account []Account) (bool /*trả về kết quả kiểm tra*/, int /*ID của user*/) {
	var check bool
	var id int

	//so sánh Authen người dùng nhập với Authen của toàn bộ Account
	for i := 0; i < len(Account); i++ {
		if Authen.Email == Account[i].Email && Authen.Password == Account[i].Password {
			//đúng thì trả về bool và ID account đã đăng nhập thành công, in ra thông báo và dừng vòng lặp,
			check = true
			id = i
			fmt.Println("Login success!")
			break
		} else {
			//sai thì trả về false
			check = false
			id = -9999
		}
	}
	return check, id
}

//hàm cộng tiền
func (ac *Account) Deposit(Account Account, Money float64 /*số tiền cần xử lý*/) Account {

	// thêm số tiền vào tài khoản
	Account.Money += Money

	//trả về account và lịch sử giao dịch sau khi hoàn tất
	return Account
}

//hàm trừ tiền
func (ac *Account) Withdraw(Account Account, Money float64 /*số tiền cần xử lý*/) (Account, bool) {

	var flag bool //trả về kết quả thất bại hay thành công

	//trừ số tiền vào tài khoản nếu tiền trong tài khoản lớn hơn số tiền rút
	if Account.Money >= Money {
		//trừ tiền
		Account.Money -= Money
		flag = true //thành công
	} else {
		flag = false //thất bại
	}
	return Account, flag
}

//kiẻm tra xem có tồn tại số tài khoản hay không
func IDcheck(Acc []Account, ID string) (bool /*trả về kết quả kiểm tra*/, int /*ID của user*/) {
	var flag bool //kết quả có hay không
	var Index int //chỉ số của tài khoản nếu có

	for i := 0; i < len(Acc); i++ {
		if Acc[i].ID == ID {
			flag = true //tồn tại
			Index = i
			break
		} else {
			flag = false //không tồn tại
		}
	}

	//trả về kết quả và chỉ số của người nhận trong mảng
	return flag, Index
}

func main() {
	//khai bảo slice tài khoản ngân hàng
	Acc := make([]Account, 20)

	//truyền giá trị 2 account để test các thao tác ngân hàng
	Acc[0] = Account{
		Name:     "Dao Trong Dat",
		Birthday: Birthday{16, 3, 1999},
		//email và pass dùng để đăng nhập, 0 là số tài khoản
		Authen:  Authen{"email", "phone", "pass", "0"},
		Money:   9999,
		History: "",
	}

	Acc[1] = Account{
		Name:     "Nguyen Thi Hong Van",
		Birthday: Birthday{27, 9, 2001},
		//email và pass dùng để đăng nhập, 1 là số tài khoản
		Authen:  Authen{"email2", "phone", "pass2", "1"},
		Money:   9999,
		History: "",
	}

	//label bắt đầu chương trình
Begin:
	/*
		đâì tiê sẽ xuất hiện lên 2 lựa chọn là đăng nhập hoặc đăng ký
	*/

	//Biến Id user login success để thao tác sau khi đăng nhập thành công
	var IdUserSuccess int

	fmt.Print("Nhập 1 để đăng nhập, 2 để đăng ký, 0 để thoát: ")
	//biến chosen để nhận vào lựa chọn
	var chosen int

	//nhập vào lựa chọn
	fmt.Scan(&chosen)
	fmt.Println("___________________________________________________________")

	/*
		switch xử lý các lựa chọn nhập vào
	*/
	switch chosen {
	//chosen = 0 thì thoát
	case 0:
		os.Exit(0)

	case 1: //chosen = 1 thì đăng nhập
		//biến để người dùng đăng nhập vào từ màn hình
		var au Authen
		var check bool = false

		fmt.Print("Nhập email: ")
		fmt.Scan(&au.Email) //nhập email

		fmt.Print("Nhập mật khẩu: ")
		fmt.Scan(&au.Password) //nhập mật khẩu

		//kiểm tra thông tin đăng nhập
		check, IdUserSuccess = Login(au, Acc[:])

		//sau khi kiểm tra thông tin đăng nhập
		if check /*đăng nhập thành công*/ {
			fmt.Println("___________________________________________________________")
			//đúng tài khoản thì chuyển tới phần tác vụ tài khoản
			goto Activities
		} else {
			//sai thì báo lỗi và trở về bát đầu
			fmt.Println(ErrLogin)
			fmt.Println("___________________________________________________________")
			goto Begin
		}

	case 2: //chosen = 2 thì đăng ký
		//tạo một account mới
		var AccAdd Account
		//thêm thông tin
		AccAdd = AccAdd.Register(AccAdd)

		//thêm vào slice account ban đầu
		Acc = append(Acc, AccAdd)
		fmt.Println("___________________________________________________________")
		goto Begin

	default: //chosen khác thì báo lỗi và quay lại
		fmt.Println(ErrChosen)
		fmt.Println("___________________________________________________________")
		goto Begin
	}

	//label tác vụ ngân hàng
Activities:
	/*
		menu lựa chọn
	*/
	fmt.Println("Bạn muốn làm gì, hãy nhập vào số tương ứng")
	fmt.Println("1. Rút tiền")
	fmt.Println("2. Gửi tiền")
	fmt.Println("3. Chuyển tiền")
	fmt.Println("4. Lịch sử giao dịch")
	fmt.Println("0. Quay lại")
	fmt.Println("___________________________________________________________")

	//khai báo biến lựa chọn
	var chosen2 int
	//nhập vào lựa chọn
	fmt.Scan(&chosen2)

	/*
		Switch các lựa chọn trên menu
		Trước và sau khi giao dịch sẽ hiển thị số dư để kiểm soát số tiền
	*/
	switch chosen2 {
	case 0: //chosen2 = 0 thì quay lại
		fmt.Println("___________________________________________________________")
		goto Begin

	case 1: //chosen2 = 1 thì rút tiền
		var numOfMoney float64 //biến này là số tiền cần rút
		var check bool         //check này để check xem rút thành công không

		//số dư trước khi rút
		fmt.Printf("Số dư hiện tại là: %.2f\n", Acc[IdUserSuccess].Money)

		fmt.Println("Nhập số tiền rút ra: ")

		//nhập vào số tiền rút
		fmt.Scan(&numOfMoney)

		//lấy ra thời gian lúc chuyển tiền
		var Withdraw = time.Now()

		//chạy hàm rút tiền
		Acc[IdUserSuccess], check = Acc[IdUserSuccess].Withdraw(Acc[IdUserSuccess], numOfMoney)

		if check /*trừ tiền thành công*/ {
			//thêm vào lịch sử giao dịch thời gian và chi tiết
			Acc[IdUserSuccess].History += Withdraw.String() + "|" + "Withdraw " + strconv.FormatFloat(numOfMoney, 'f', 1, 64) + "\n"
			fmt.Printf("Rút thành công %.2f khỏi tài khoản\n", numOfMoney)
		} else { //trừ tiền thất bại
			fmt.Println("Số tiền rút lớn hơn tài khoản hiện có, rút thất bại")
		}

		//số dư sau khi rút
		fmt.Printf("Số dư hiện tại là: %.2f \n", Acc[IdUserSuccess].Money)
		fmt.Println("___________________________________________________________")

		goto Activities

	case 2: //chosen = 2 thì gửi tiền
		var numOfMoney float64 //biến này là số tiền cần nhập

		//số dư trước khi gửi
		fmt.Printf("Số dư hiện tại là: %.2f\n", Acc[IdUserSuccess].Money)

		fmt.Println("Nhập số tiền muốn gửi vào: ")
		//nhập vào số tiền gửi
		fmt.Scan(&numOfMoney)

		//lấy ra thời gian lúc chuyển tiền
		var timeDeposit = time.Now()

		//chạy hàm gửi tiền
		Acc[IdUserSuccess] = Acc[IdUserSuccess].Deposit(Acc[IdUserSuccess], numOfMoney)

		//thêm vào lịch sử giao dịch thời gian và chi tiết
		Acc[IdUserSuccess].History += timeDeposit.String() + "|" + "Deposited " + strconv.FormatFloat(numOfMoney, 'f', 1, 64) + "\n"

		//thông báo thành công
		fmt.Printf("Rút thành công %.2f khỏi tài khoản\n", numOfMoney)

		//số dư sau khi gửi thêm tiền
		fmt.Printf("Số dư hiện tại là: %.2f \n", Acc[IdUserSuccess].Money)
		fmt.Println("___________________________________________________________")
		goto Activities

	case 3: //chosen = 3 thì chuyển tiền
		var numOfMoney float64 //số tiền cần chuyển
		var IdReceiver string  //id ngươi nhận
		var idCheck bool       //check xem id người nhận tồn tại không
		var IndexReceiver int  //vị trí người nhận trong slice

		//số dư trước khi chuyển
		fmt.Printf("Số dư hiện tại là: %.2f\n", Acc[IdUserSuccess].Money)

		//nhập số tài khoản người nhận
		fmt.Println("Nhập số tài khoản người nhận: ")
		fmt.Scan(&IdReceiver)

		//check xem có tồn tại số tài khoản không
		idCheck, IndexReceiver = IDcheck(Acc[:], IdReceiver)

		if idCheck /*tồn tại ID người nhận*/ {
			fmt.Println("Nhập số tiền muốn chuyển đi: ")
			//nhập vào số tiền chuyển
			fmt.Scan(&numOfMoney)

			//trừ tiền từ tài khoản người gửi
			var check bool

			//lấy ra thời gian lúc bắt đầu giao dịch
			var timeDeposit = time.Now()
			Acc[IdUserSuccess], check = Acc[IdUserSuccess].Withdraw(Acc[IdUserSuccess], numOfMoney)

			if check /*trừ tiền thành công*/ {
				//cộng tiền vào tài khoản người nhận
				Acc[IndexReceiver] = Acc[IndexReceiver].Deposit(Acc[IndexReceiver], numOfMoney)

				//ghi lại lịch sử giao dịch người gửi và người nhận
				Acc[IdUserSuccess].History += timeDeposit.String() + "|" + " Sent " + strconv.FormatFloat(numOfMoney, 'f', 1, 64) + " to " + Acc[IndexReceiver].ID + " - " + Acc[IndexReceiver].Name + "\n"
				Acc[IndexReceiver].History += timeDeposit.String() + "|" + " receiver " + strconv.FormatFloat(numOfMoney, 'f', 1, 64) + " from " + Acc[IdUserSuccess].ID + " - " + Acc[IdUserSuccess].Name + "\n"

				//thông báo
				fmt.Printf("Chuyển thành công %.2f tới tài khoản %s - %s \n", numOfMoney, Acc[IndexReceiver].ID, Acc[IndexReceiver].Name)
			} else { //trừ tiền thất bại
				fmt.Println("Số tiền chuyển lớn hơn tài khoản hiện có, rút thất bại")
			}
		} else { //k tồn tại ID ngừi nhận
			fmt.Println("Không tìm thấy số tài khoản")
		}

		//số dư sau khi gửi tiền
		fmt.Printf("Số dư hiện tại là: %.2f \n", Acc[IdUserSuccess].Money)
		fmt.Println("___________________________________________________________")
		goto Activities

	case 4: //chosen = 4 thì show history
		fmt.Print(Acc[IdUserSuccess].History)
		fmt.Println("___________________________________________________________")
		goto Activities

	default: //chosen khác thì báo lỗi và quay lại
		fmt.Print(ErrChosen)
		fmt.Println("___________________________________________________________")
		goto Activities
	}
}
