package main

import (
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"
)

var(
	ErrLogin error = errors.New("login error, your Email or Password is invalid")
	ErrChosen error = errors.New("invalid chosen")
	wg sync.WaitGroup
	mt sync.Mutex
)

type Bank interface{
	//rút tiền
	Withdraw()
	//gửi tiền
	Deposit()
	//gửi tiền
	Send()
}

//kiểu thông tin xác thực
type Authen struct{
	ID string
}

//kiểu thông tin tài khoản
type Account struct{
	Name string
	Authen
	Money float64
	History string
}

//hàm gửi tiền
func (ac *Account) Deposit(Account Account /*Account cần gửi tiền*/, Money float64/*Số tiền cần gửi*/) Account{
	// thêm số tiền vào tài khoản
	Account.Money += Money
	
	//lấy ra thời gian lúc chuyển tiền
	var timeDeposit = time.Now()

	//history là thời gian chuyển sang chuỗi và thêm chi tiết giao dịch
	Account.History = Account.History + timeDeposit.String() + "|" + " Deposited " + strconv.FormatFloat(Money, 'f', 1, 64) + "\n"
	return Account
}

//hàm rút tiền
func (ac *Account) Withdraw(Account Account/*Account cần rút tiền*/, Money float64/*Số tiền cần rút*/) Account{
	//trừ số tiền vào tài khoản nếu tiền trong tài khoản lớn hơn số tiền rút
	if(Account.Money >= Money){
		//trừ tiền
		Account.Money -= Money
		//lấy ra thời gian lúc chuyển tiền
		var Withdraw = time.Now()

		//history là thời gian chuyển sang chuỗi và thêm chi tiết giao dịch
		Account.History = Account.History + Withdraw.String() + "|" + " Withdraw " + strconv.FormatFloat(Money, 'f', 1, 64) + "\n"
	}
	return Account
}

//tạo một goroutine worker
/*
	thực hiện chuyển tiền cũng chỉ là trừ tiền và thêm tiền của các tài khoản nên em chỉ cho job thực hiện chuyển và nhận tiền
*/

func worker(jobs chan Account, results chan Account, Money float64/*Số tiền cần thao tác*/) {  
    for job := range jobs {
		//thực hiện gửi tiền
		mt.Lock()
		tmp := job.Deposit(job, Money-123)
		mt.Unlock()
		//thực hiện rút tiền
		mt.Lock()
        output := tmp.Withdraw(tmp, Money)
		mt.Unlock()
        results <- output
    }
    wg.Done()
}

//tạo ra số lượng goroutine worker cần thiết.
func createWorkerPool(noOfWorkers int, jobs chan Account, results chan Account, Money float64/*Số tiền cần thao tác*/) {  
	//mỗi worker sẽ lấy việc ra để làm
    for i := 0; i < noOfWorkers; i++ {
        wg.Add(1)
        go worker(jobs, results, Money)
    }
    wg.Wait()
    close(results)
}

//cấp phát job cho các worker
func allocate(Acc []Account, jobs chan Account) {  
	//chuyển giá trị của slice Acc vào channel jobs
    for i := 0; i <len(Acc); i++ {
		jobs <- Acc[i]
	}
	close(jobs)
}

//hàm đọc kết quả từ channel results và in ra kết quả.
func result(done chan bool, results chan Account, Account []Account) {
    //cập nhật lại kết quả của Account[] sau giao dịch
	for i :=0; i < len(Account); i++ {
       Account[i] = <-results
    }

	//in ra lịch sử giao dịch của từng account
	for i :=0; i < len(Account); i++ {
        fmt.Println("History Account" , i , "\n" , Account[i].History)
    }
    done <- false
}

func main(){
	//khai bảo slice tài khoản ngân hàng
	Acc := make([]Account, 20)

	Done := make(chan bool)

	//tạo 20 account
	for i := 0; i < 20; i++ {
		Acc[i] = Account{
			Name:     "User" + strconv.Itoa(i),
			//Au then chứa trường là số tài khoản, để cho nhanh thì bằng giá trị của index luôn
			Authen:   Authen{strconv.Itoa(i)},
			//mặc định tiền của mỗi người là 5000
			Money:    5000,
			History:  "",
		}
	}

	//tạo 2 channel 
	var jobs = make(chan Account, 20)  
	var results = make(chan Account, 20) 
	
	//cấp phát jobs cho worker
	go allocate(Acc[:], jobs)
	
	//cập nhật lại slice Acc và in r lịch sử
	go result(Done, results, Acc[:])

	//tạo ra 5 worker làm job 
	createWorkerPool(5, jobs, results, 300)
	<-Done
}
